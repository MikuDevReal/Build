package com.example.miku_ai_assistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "miku_ai/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "screenshot" -> {
                        // Android screenshot is requested through AccessibilityService.
                        MikuAccessibilityService.instance?.takeScreenshot()
                        result.success(null)
                    }
                    "back" -> {
                        MikuAccessibilityService.instance?.performGlobalBack()
                        result.success(null)
                    }
                    "typeAndSend" -> {
                        val text = call.argument<String>("text") ?: ""
                        MikuAccessibilityService.instance?.typeAndSend(text)
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
