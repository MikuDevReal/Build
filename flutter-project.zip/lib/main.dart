import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

const native = MethodChannel('miku_ai/native');

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(JarvisTaskHandler());
}

class JarvisTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}
  @override
  void onRepeatEvent(DateTime timestamp) {}
  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}
  @override
  void onReceiveData(Object data) {}
  @override
  void onNotificationButtonPressed(String id) {}
  @override
  void onNotificationPressed() {}
  @override
  void onNotificationDismissed() {}
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterForegroundTask.initCommunicationPort();
  runApp(const JarvisApp());
}

class JarvisApp extends StatefulWidget {
  const JarvisApp({super.key});
  @override State<JarvisApp> createState() => _JarvisAppState();
}

class _JarvisAppState extends State<JarvisApp> {
  final speech = stt.SpeechToText();
  final tts = FlutterTts();
  bool enabled = false;
  bool listening = false;
  bool commandMode = false;
  String status = 'JARVIS siap';
  String heard = '';
  Timer? restartTimer;

  @override
  void initState() {
    super.initState();
    _setup();
  }

  Future<void> _setup() async {
    await Permission.microphone.request();
    await speech.initialize(
      onStatus: (s) {
        if (!mounted) return;
        setState(() => listening = s == 'listening');
        if (enabled && s == 'notListening') {
          restartTimer?.cancel();
          restartTimer = Timer(const Duration(milliseconds: 600), _listen);
        }
      },
      onError: (_) {
        if (enabled) {
          restartTimer?.cancel();
          restartTimer = Timer(const Duration(seconds: 1), _listen);
        }
      },
    );
    await tts.setLanguage('id-ID');
    await tts.setSpeechRate(0.48);
  }

  Future<void> _speak(String text) async {
    await tts.stop();
    await tts.speak(text);
  }

  Future<void> toggleJarvis() async {
    if (enabled) {
      setState(() { enabled = false; commandMode = false; status = 'JARVIS dimatikan'; });
      await speech.stop();
      await FlutterForegroundTask.stopService();
      return;
    }

    final ok = await Permission.microphone.request();
    if (!ok.isGranted) {
      setState(() => status = 'Izin mikrofon diperlukan');
      return;
    }

    setState(() { enabled = true; status = 'Mendengarkan wake word...'; });
    await _startForeground();
    await _speak('JARVIS online. Saya siap, Bos.');
    _listen();
  }

  Future<void> _startForeground() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'miku_jarvis',
        channelName: 'Miku JARVIS',
        channelDescription: 'Mendengarkan wake word di background',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
      ),
      iosNotificationOptions: const IOSNotificationOptions(),
      foregroundTaskOptions: const ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(10000),
        autoRunOnBoot: true,
      ),
    );

    if (await FlutterForegroundTask.isRunningService) return;
    await FlutterForegroundTask.startService(
      notificationTitle: 'Miku JARVIS aktif',
      notificationText: 'Mendengarkan wake word “Hey Miku”',
      callback: startCallback,
    );
  }

  Future<void> _listen() async {
    if (!enabled || listening) return;
    await speech.listen(
      localeId: 'id_ID',
      listenFor: const Duration(seconds: 12),
      pauseFor: const Duration(seconds: 2),
      partialResults: true,
      onResult: (r) {
        final phrase = r.recognizedWords.trim();
        if (!mounted) return;
        setState(() => heard = phrase);
        final low = phrase.toLowerCase();

        if (!commandMode && _hasWakeWord(low)) {
          commandMode = true;
          _speak('Ya, Bos?');
          final after = _removeWakeWord(low);
          if (after.isNotEmpty) handleCommand(after);
          return;
        }

        if (commandMode && r.finalResult) {
          handleCommand(low);
          commandMode = false;
        }
      },
    );
  }

  bool _hasWakeWord(String s) =>
      s.contains('hey miku') || s.contains('hei miku') ||
      s.contains('hai miku') || s.contains('jarvis');

  String _removeWakeWord(String s) {
    for (final x in ['hey miku', 'hei miku', 'hai miku', 'jarvis']) {
      if (s.contains(x)) return s.replaceFirst(x, '').trim();
    }
    return s;
  }

  Future<void> handleCommand(String cmd) async {
    setState(() => status = 'Menjalankan: $cmd');

    if (cmd.contains('screenshot') || cmd.contains('ambil layar') ||
        cmd.contains('foto layar')) {
      await native.invokeMethod('screenshot');
      await _speak('Screenshot sudah diambil, Bos.');
      return;
    }

    if (cmd.contains('kembali') || cmd == 'back') {
      await native.invokeMethod('back');
      await _speak('Baik, Bos.');
      return;
    }

    if (cmd.contains('balas whatsapp') || cmd.contains('balas wa') ||
        cmd.contains('balas chat')) {
      final msg = _extractMessage(cmd);
      if (msg.isEmpty) {
        await _speak('Pesannya apa, Bos?');
        commandMode = true;
        return;
      }
      await _openWhatsApp();
      await Future.delayed(const Duration(milliseconds: 1500));
      await native.invokeMethod('typeAndSend', {'text': msg});
      await _speak('Pesan sudah diproses, Bos.');
      return;
    }

    final app = _extractApp(cmd);
    if (app.isNotEmpty) {
      final opened = await _openApp(app);
      await _speak(opened ? 'Membuka $app, Bos.' : 'Aplikasi $app tidak ditemukan.');
      return;
    }

    await _speak('Maaf Bos, saya belum memahami perintah itu.');
  }

  String _extractMessage(String s) {
    for (final p in ['bilang ', 'katakan ', 'tulis ', 'pesan ']) {
      final i = s.indexOf(p);
      if (i >= 0) return s.substring(i + p.length).trim();
    }
    return '';
  }

  String _extractApp(String s) {
    for (final p in ['buka ', 'jalankan ', 'open ']) {
      final i = s.indexOf(p);
      if (i >= 0) return s.substring(i + p.length).trim();
    }
    return '';
  }

  Future<void> _openWhatsApp() async {
    final opened = await native.invokeMethod<bool>('openApp', {
      'packageName': 'com.whatsapp',
    });
    if (opened != true) {
      await native.invokeMethod<bool>('openApp', {
        'packageName': 'com.whatsapp.w4b',
      });
    }
  }

  Future<bool> _openApp(String name) async {
    final n = name.toLowerCase().trim();
    const packages = <String, String>{
      'youtube': 'com.google.android.youtube',
      'whatsapp': 'com.whatsapp',
      'chrome': 'com.android.chrome',
      'google chrome': 'com.android.chrome',
      'gmail': 'com.google.android.gm',
      'telegram': 'org.telegram.messenger',
      'instagram': 'com.instagram.android',
      'facebook': 'com.facebook.katana',
      'settings': 'com.android.settings',
      'pengaturan': 'com.android.settings',
    };
    final packageName = packages[n];
    if (packageName == null) return false;
    final opened = await native.invokeMethod<bool>('openApp', {
      'packageName': packageName,
    });
    return opened == true;
  }

  @override
  void dispose() {
    restartTimer?.cancel();
    speech.stop();
    tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        appBar: AppBar(title: const Text('Miku JARVIS')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(enabled ? Icons.hearing : Icons.hearing_disabled, size: 90),
                const SizedBox(height: 20),
                Text(status, textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 20)),
                const SizedBox(height: 10),
                Text(heard.isEmpty ? 'Ucapkan “Hey Miku”' : heard,
                    textAlign: TextAlign.center),
                const SizedBox(height: 30),
                FilledButton.icon(
                  onPressed: toggleJarvis,
                  icon: Icon(enabled ? Icons.power_settings_new : Icons.power),
                  label: Text(enabled ? 'MATIKAN JARVIS' : 'AKTIFKAN JARVIS'),
                ),
                const SizedBox(height: 24),
                const Text(
                  'Hands-free:\n“Hey Miku, buka YouTube”\n“Hey Miku, screenshot”\n“Hey Miku, balas WhatsApp, bilang saya sedang di jalan”',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
