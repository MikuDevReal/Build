import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const MikuAiApp());
}

class MikuAiApp extends StatelessWidget {
  const MikuAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Miku AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF35D0FF),
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF060B16),
      ),
      home: const HomeScreen(),
    );
  }
}
