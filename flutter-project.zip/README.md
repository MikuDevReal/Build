# Miku JARVIS Hands-Free

Versi hands-free dari Miku AI Assistant.

Wake word:
- "Hey Miku"
- "Hei Miku"
- "Hai Miku"
- "Jarvis"

Contoh:
- "Hey Miku, buka YouTube"
- "Hey Miku, screenshot"
- "Hey Miku, balas WhatsApp, bilang saya sedang di jalan"

## Build
flutter pub get
flutter build apk --release

## Catatan
Aplikasi memakai foreground service agar tetap berjalan saat layar mati/terkunci.
Android dapat membatasi mikrofon/background tergantung merek HP, mode hemat baterai,
dan kebijakan sistem. HP yang benar-benar power-off tidak dapat mendengar.

Wake-word engine khusus (misalnya Porcupine/Vosk/Whisper lokal) lebih cocok untuk
versi produksi karena Speech-to-Text Android dapat berhenti setelah timeout.
