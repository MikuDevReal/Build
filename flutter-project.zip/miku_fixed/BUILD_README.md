# Miku AI - GitHub Actions build

This project includes a corrected `.github/workflows/build.yml` for the incomplete Android/Gradle scaffolding in the original project.

The workflow preserves the custom Miku AI Android source, regenerates missing Flutter Android/Gradle files, builds a release APK, and uploads it as the `Miku-AI-APK` artifact.
