# Miku AI - GitHub Actions build

Workflow ini khusus untuk project Flutter Miku AI.

## Perbaikan utama

- Tidak lagi mencari `build-config.json` untuk menentukan jenis project.
- Otomatis menggunakan project ini sebagai Flutter project karena memiliki `pubspec.yaml`.
- Tidak lagi memasang Gradle 8.9 secara manual dengan SDKMAN.
- Tidak lagi memaksa `compileSdk 36`; versi Android/Gradle mengikuti template Flutter yang sedang dipakai.
- Karena folder `android/` pada repository belum lengkap, workflow mencadangkan source Android custom Miku, menjalankan `flutter create`, lalu mengembalikan source custom tersebut.
- Menjalankan `flutter pub get` lalu `flutter build apk --release`.
- APK hasil build di-upload sebagai artifact `Miku-AI-APK`.

## Cara menjalankan

Push file project ke branch `build`, atau jalankan workflow secara manual dari tab **Actions** menggunakan **Run workflow**.


Build fix: AndroidManifest explicitly declares Flutter Android embedding v2, and the discontinued device_apps dependency was removed in favor of native package launching for common apps.
